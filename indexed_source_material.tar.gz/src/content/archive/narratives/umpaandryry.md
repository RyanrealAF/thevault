---
title: "Umpa and Ryry"
date: 2026-01-10
category: "archive"
tags: ["narrative"]
---

### Chapter 1: "Echoes of a Schoolyard Crush"

In the backdrop of our shared history, Jess and I navigated the intricate world of school, where her longstanding crush clashed with my fixation on Kandice. The corridors echoed with unspoken emotions, setting the stage for a journey beyond conventional boundaries.

As the seasons of our academic lives unfolded, Jess's admiration for me became a silent undercurrent, weaving through the fabric of our shared classes and schoolyard escapades. However, my attention was entangled in the allure of Kandice, who had become the apple of my eye, a captivating figure casting a spell that diverted my focus from Jess's silent yearning.

---

### Chapter 2: "An Unconventional Agreement"

Fate took an unexpected turn, catapulting me into the clutches of the law, and an unconventional agreement emerged as an unlikely refuge. The bizarre arrangement, initially rooted in the peculiar condition of being naked in a lady's bed, morphed into an increasingly uncomfortable ordeal.

Navigating this surreal scenario, I stumbled upon the living room and, to my astonishment, discovered Jess's presence. seizing the opportunity, I called Jess in, and together, we staged a performance for the lady, turning the bizarre circumstance into an unexpected display of solidarity.

---

### Chapter 3: "Life on the Run"

The eccentricity of that moment became a catalyst for a new chapter – a life on the run. Jess and I sought refuge in a hotel, marking the beginning of a fugitive existence filled with challenges and uncertainties. As we navigated this uncharted territory, our connection deepened, weaving a tapestry of shared experiences that surpassed the unconventional circumstances that initially brought us together.

Amidst the challenges of life on the run, we found solace in the authenticity of our connection. The shared laughter, the whispered conversations in the dead of the night, and the stolen moments of quiet intimacy became the threads that wove our bond into a resilient fabric, with each passing day strengthening the ties that bound us.

---

### Chapter 4: "Confronting Choices"

The fugitive life reached a pivotal juncture where the weight of my decisions and the consequences of evading the law became too burdensome to carry. Faced with the daunting reality, I made the difficult choice to turn myself in, setting the stage for a narrative shift that would unfold into an odyssey of escape, camaraderie, and the unwavering confrontation of the consequences of my actions.

The decision to confront the legal consequences was a momentous one, a turning point that demanded introspection and an unflinching gaze at the choices that led to this juncture. It was a chapter marked by the shadows of uncertainty and the acknowledgment that sometimes, facing the consequences becomes an inevitable step on the path to redemption.

---

### Chapter 5: "Navigating Prison Realities"

In the midst of my initial prison term, Jess and I clung together, navigating the harsh realities of confinement. The cold, unforgiving walls of the prison became our shared reality, the echoes of distant conversations and the persistent clang of metal doors shaping the soundtrack of our days.

The agonizing wait for mail and calls intensified the solitude, each passing day feeling like an endless journey through isolation's maze. Faced with the torment of separation, I consciously chose to halt constant communication, embracing the solitude that defined my sentence. The silence became a canvas for the raw emotions of incarceration, each stroke revealing the intricate tapestry of survival etched into my existence.

---

### Chapter 6: "Post-Prison Adaptation"

Upon release, the post-prison world unfolded, offering both daunting challenges and liberating moments. Reconnecting with Jess on Facebook, her readiness for a fresh start became evident, even as I settled into a halfway house. The adaptation to a world that had changed during my incarceration proved to be both a daunting and liberating experience.

The process of adaptation was a delicate dance between newfound freedom and lingering constraints. Reentering a society that had moved forward demanded a careful balancing act, and Jess's unwavering support became a beacon of stability amid the turbulent seas of change. A twist of fate led to a union gig as a grounds manager, overseeing three cemeteries, a responsibility that proved more intricate than expected.

---

### Chapter 7: "Building a Life Amidst Uncertainties"

Navigating bureaucratic hurdles, I secured approval to build a life from the ground up. Within a year, we carved out a sanctuary amidst life's uncertainties, transforming the remnants of past mistakes into the foundation for a new beginning. A twist of fate led me to a union gig as a grounds manager, overseeing three cemeteries, a responsibility that proved more intricate than expected.

The responsibilities of overseeing cemeteries became metaphors for the challenges we face in life. From managing irrigation systems to addressing building repairs, each task became a gravestone in the cemetery of challenges, testaments to the grit required for stability. Jess's commitment and sacrifices during this period echoed the resilience and determination woven into our journey, solidifying the foundation of our shared life.

---

### Chapter 8: "Resurfacing Shadows"

Amidst the challenges of building a life, a figure from my past, Kandice, resurfaced. Exploiting Jess's frustrations, Kandice wove a deceptive narrative, planting seeds of doubt about my fidelity. The threads of deceit were woven into our lives, unnoticed until the echoes of manipulation eroded the bonds we fought hard to build.

Kandice's return cast shadows over the sanctuary we were diligently crafting. The once-sturdy walls of trust began to crack, and the foundation of our shared life trembled under the weight of manipulation. It was a period marked by soul-searching, confronting the haunting echoes of deception, and recognizing the fragility of trust in the face of calculated schemes.

---

### Chapter 9: "Haunted Homecoming"

Returning home one day, Kandice's plan became painfully evident. The once-vibrant space we built stood hauntingly empty, a stark testament to the destructive power of deceit. Kandice's tactics severed our ties, leaving me to grapple with the wreckage of a life I fought hard to build. The aftermath was a harrowing odyssey, Jess and I facing the challenge of rebuilding from ruins. Scars left by Kandice's scheming lingered, casting shadows on fragments of trust. It was a period marked by soul-searching, confronting the haunting echoes of deception, and navigating the intricate dance of rebuilding a life from the ashes.

---

### Chapter 10: "Revelations and Reconnections"

Years later, reconnecting with Jess unveiled the truth like a tattered mural, exposing Kandice's manipulative tactics. Despite our commitment to friendship, scars of betrayal ran deep. Attempts to rekindle love collided with echoes of betrayal, trying to rebuild a shattered mirror reflecting fragments of affection while avoiding the sharp edges of distrust.

The profound challenge lay in the relentless battle with my soul. Despite the genuine desire to reignite passion, my soul remained a stoic gatekeeper, unwilling to yield. Imagine the internal conflict of reaching out to someone you loved for a decade and feeling your core whisper a resolute "nope." Days turned into weeks, and weeks into months as Jess and I grappled with dissonance between actions and my soul's resistance. It became an emotional odyssey, exploring affection's intricacies against the backdrop of shared history.

---

### Chapter 11: "Exploring Uncharted Territories"

In navigating this emotional labyrinth, we found solace in familiar rituals – getting high and engaging in intimacy. Yet, my soul's reluctance cast a somber undertone, the rhythm haunted by dissonant notes. It was an exploration of love beyond conventional boundaries, delving into the heart's resistance. Despite shared history, attempts to rekindle love revealed the undeniable truth. My soul, a sage guide through emotion's maze, stood firm in refusal.

The "nope" became an unspoken anthem, resonating through our connection's corridors. We spent days, weeks, and months grappling with the poignant realization that the heart's journey sometimes leads down paths of acceptance rather than revival. In the end, our connection transformed into a unique camaraderie – a dynamic friendship embracing the authenticity of shared struggles and acknowledging life's unyielding beats.

---

### Chapter 12: "Acceptance and Understanding"

The attempt to love again became a lesson in accepting emotions' fluid nature, a poetic exploration of the heart's resilience recognizing that not every love story follows a traditional narrative. Sometimes, the most profound connections emerge from the unexpected harmonies of acceptance and understanding. Our journey became a testament to the complexities of love, echoing the universal truth that the heart's whispers guide us through the ever-shifting landscapes of emotion.

In the acceptance of our connection's evolution, Jess and I found a deeper understanding that transcended the boundaries of conventional love. The echoes of past experiences lingered, but they became the brushstrokes painting the canvas of our shared history. In embracing the nuances of our unique bond, we discovered the beauty in acceptance, and our connection became a tapestry woven with threads of resilience, friendship, and the unwavering beats of life.
